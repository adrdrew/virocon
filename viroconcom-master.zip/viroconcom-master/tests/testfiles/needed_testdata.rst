===================
Benötigte Testfiles
===================


HDC
---

  - 2D
  - 3D
  - 4D
  - mind. einmal bimodale Verteilung
  - nach Möglichkeit jeweils in jeder Dimension unterschiedliche Abtastung
  - NormalDistribution

IFORM
-----
  - Gibt es IFORM Implementierungen, die man als Referenz nutzen kann?

Fitten
------
  - evtl. Daten von bekannter Verteilung generieren (z.B. mit Matlab) und dann fitten und vergleichen
