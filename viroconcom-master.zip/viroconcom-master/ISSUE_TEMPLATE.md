**I'm submitting a ...**
  - [ ] bug report
  - [ ] feature request
  - [ ] code improvement request

## Expected behavior
**How should it work (with the bug fixed or the feature implemented)?**


**Screenshot**


## Actual behavior
**How does it currently work (with the bug causing problems or without the feature)?**


**Screenshot**


## Steps to reproduce the problem (how to see the actual behavior)

  1.
  2.
  3.
